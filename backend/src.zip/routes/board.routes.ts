import express from "express";

const boardRoute = express();

export default boardRoute;
