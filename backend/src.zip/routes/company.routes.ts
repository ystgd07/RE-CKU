import expess, { Request, Response, NextFunction } from "express";
const companyRouter = expess();

export default companyRouter;
