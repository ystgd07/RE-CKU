import { CreateUserDto } from "src/routes/dto/create-individual.dto";
import { dataSource, db } from "./index.schema";
import { roleEnum, User } from "./schemas/index.schema";

export const findOneUser = async (data: number | string) => {
  let user = null;
  // 파라미터로 들어온 data 값이 num이면 id로 찾고, 아니면 email로 찾음
  switch (typeof data) {
    case "string":
      user = await db.query(`SELECT * FROM user WHERE email=?`, [data]);
      break;
    default:
      // user = await dataSource.getRepository(User).findOne({ where: { id: data } });
      user = await db.query(`SELECT * FROM user WHERE id=?`, [data]);
  }

  return user[0][0];
};

export const createIndiUser = async (data: CreateUserDto) => {
  const { username, email, phoneNumber, password } = data;
  // const newUser = dataSource.getRepository(User).create({ ...data });
  const newUser = db.query(`INSERT INTO user(username,email,phoneNumber,password) VALUES(?,?,?,?)`, [
    username,
    email,
    phoneNumber,
    password,
  ]);

  return newUser;
};

type UpdateData = {
  phoneNumber: string | undefined;
  password: string | undefined;
  role: roleEnum | undefined;
  RT: string | undefined;
  active: boolean | undefined;
};
export const updateUser = async (id: number, data: UpdateData): Promise<boolean> => {
  const { phoneNumber, password, role, RT, active } = data;
  const toUpdate = {
    ...(phoneNumber && { phoneNumber }),
    ...(password && { password }),
    ...(role && { role }),
    ...(RT && { RT }),
    ...(active && { active }),
  };
  await dataSource.getRepository(User).update(id, toUpdate);
  return true;
};
